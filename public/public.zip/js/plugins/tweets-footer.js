$(document).ready(function() {
			    "use strict";
					var config2 = {
				      "id": '579924271629094913',
				      "domId": 'tweets-footer',
				      "maxTweets": 5,
				      "enableLinks": true,
				      "showUser": false,
				      "showTime": true,
				      "showImages": false,
				      "lang": 'en'
				    };
				    twitterFetcher.fetch(config2);
			});