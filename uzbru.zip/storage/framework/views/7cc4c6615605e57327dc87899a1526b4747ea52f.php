<?php echo $__env->renderWhen(!empty($widget['wrapper']), 'backpack::widgets.inc.wrapper_start', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>

<div class="<?php echo e($widget['class'] ?? 'alert alert-primary'); ?>" role="alert">

	<?php if(isset($widget['close_button']) && $widget['close_button']): ?>	
	<button class="close" type="button" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
	<?php endif; ?>

	<?php if(isset($widget['heading'])): ?>
	<h4 class="alert-heading"><?php echo $widget['heading']; ?></h4>
	<?php endif; ?>

	<?php if(isset($widget['content'])): ?>
	<p><?php echo $widget['content']; ?></p>
	<?php endif; ?>

</div>

<?php echo $__env->renderWhen(!empty($widget['wrapper']), 'backpack::widgets.inc.wrapper_end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?><?php /**PATH /opt/lampp/htdocs/UzBRU/vendor/backpack/crud/src/resources/views/base/widgets/alert.blade.php ENDPATH**/ ?>