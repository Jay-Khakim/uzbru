<!-- This file is used to store topbar (right) items -->



<?php /**PATH /opt/lampp/htdocs/UzBRU/resources/views/vendor/backpack/base/inc/topbar_right_content.blade.php ENDPATH**/ ?>