<!-- expand/minimize button column -->
<span class="details-control text-center cursor-pointer m-r-5">
	<i class="la la-plus-square details-row-button cursor-pointer" data-entry-id="<?php echo e($entry->getKey()); ?>"></i>
</span><?php /**PATH /opt/lampp/htdocs/UzBRU/vendor/backpack/crud/src/resources/views/crud/columns/inc/details_row_button.blade.php ENDPATH**/ ?>