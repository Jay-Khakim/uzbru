<!-- address_algolia input -->

<?php
    $field['store_as_json'] = $field['store_as_json'] ?? false;
    $field['wrapper']['algolia-wrapper'] = $field['wrapper']['algolia-wrapper'] ?? 'true';
    $field['config'] = [
        'field' => $field['name'],
        'full' => $field['store_as_json'],
    ];
    $field['value'] = old(square_brackets_to_dots($field['name'])) ?? $field['value'] ?? $field['default'] ?? '';

    // the field should work whether or not Laravel attribute casting is used
    if (isset($field['value']) && (is_array($field['value']) || is_object($field['value']))) {
        $field['value'] = json_encode($field['value']);
    }
?>

<?php echo $__env->make('crud::fields.inc.wrapper_start', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <label><?php echo $field['label']; ?></label>

    <?php echo $__env->make('crud::fields.inc.translatable_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if($field['store_as_json']): ?>
    <input type="hidden" 
        value='<?php echo e($field['value']); ?>' 
        name="<?php echo e($field['name']); ?>" 
        data-algolia-hidden-input="<?php echo e($field['name']); ?>">
    <?php endif; ?>

    <?php if(isset($field['prefix']) || isset($field['suffix'])): ?> <div class="input-group"> <?php endif; ?>
    <?php if(isset($field['prefix'])): ?> <div class="input-group-addon"><?php echo $field['prefix']; ?></div> <?php endif; ?>

    <input
        type="text"
        data-config='<?php echo json_encode((object)$field['config'], 15, 512) ?>'
        data-init-function="bpFieldInitAddressAlgoliaElement"
        <?php if(!$field['store_as_json']): ?>
        name="<?php echo e($field['name']); ?>"
        value="<?php echo e($field['value']); ?>"
        <?php endif; ?>
        <?php echo $__env->make('crud::fields.inc.attributes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    >

    <?php if(isset($field['suffix'])): ?> <div class="input-group-addon"><?php echo $field['suffix']; ?></div> <?php endif; ?>
    <?php if(isset($field['prefix']) || isset($field['suffix'])): ?> </div> <?php endif; ?>

    
    <?php if(isset($field['hint'])): ?>
        <p class="help-block"><?php echo $field['hint']; ?></p>
    <?php endif; ?>
<?php echo $__env->make('crud::fields.inc.wrapper_end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>






<?php if($crud->fieldTypeNotLoaded($field)): ?>
    <?php
        $crud->markFieldTypeAsLoaded($field);
    ?>

    
    <?php $__env->startPush('crud_fields_styles'); ?>
        <style>
            .ap-input-icon.ap-icon-pin {
                right: 5px !important; }
            .ap-input-icon.ap-icon-clear {
                right: 10px !important; }
        </style>
    <?php $__env->stopPush(); ?>

    
    <?php $__env->startPush('crud_fields_scripts'); ?>
    <script src="<?php echo e(asset('packages/places.js/dist/cdn/places.min.js')); ?>"></script>
    <script>
            window.AlgoliaPlaces = window.AlgoliaPlaces || {};

            function bpFieldInitAddressAlgoliaElement(element) {
                $addressConfig = element.data('config');
                $hiddenInput = element.parent("[algolia-wrapper]").find('input[type=hidden]');
                $place = places({ container: element[0] });

                // set id to something unique
                $randomNumber = Math.round(Math.random() * 1000000000);
                element.attr('id', 'algolia_input_'+$randomNumber);

                function clearInput() {
                    if( !element.val().length ){
                        $hiddenInput.val('');
                    }
                }

                if( $addressConfig.full ){

                    $place.on('change', function(e){
                        var result = JSON.parse(JSON.stringify(e.suggestion));
                        delete(result.highlight); delete(result.hit); delete(result.hitIndex);
                        delete(result.rawAnswer); delete(result.query);
                        $hiddenInput.val( JSON.stringify(result) );
                    });

                    element.on('change blur', clearInput);
                    $place.on('clear', clearInput);

                    if( $hiddenInput.val().length ){
                        var existingData = JSON.parse($hiddenInput.val());
                        element.val(existingData.value);
                    }
                }

                window.AlgoliaPlaces[ element.attr('id') ] = $place;
            }
    </script>
    <?php $__env->stopPush(); ?>

<?php endif; ?>


<?php /**PATH /opt/lampp/htdocs/UzBRU/vendor/backpack/crud/src/resources/views/crud/fields/address_algolia.blade.php ENDPATH**/ ?>