<!-- This file is used to store sidebar items, starting with Backpack\Base 0.9.0 -->
<li class="nav-item"><a class="nav-link" href="<?php echo e(backpack_url('dashboard')); ?>"><i class="la la-home nav-icon"></i> <?php echo e(trans('backpack::base.dashboard')); ?></a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('media')); ?>'><i class='nav-icon la la-youtube'></i> Media</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('membership')); ?>'><i class='nav-icon la la-users'></i> Memberships</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('news')); ?>'><i class='nav-icon la la-blog'></i> News</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('partner')); ?>'><i class='nav-icon la la-user'></i> Partners</a></li>
<li class='nav-item'><a class='nav-link' href='<?php echo e(backpack_url('staff')); ?>'><i class='nav-icon la la-user-alt'></i> Staff</a></li><?php /**PATH /opt/lampp/htdocs/UzBRU/resources/views/vendor/backpack/base/inc/sidebar_content.blade.php ENDPATH**/ ?>