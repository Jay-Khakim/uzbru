<?php $__env->startSection('title'); ?>
    <title><?php echo app('translator')->get("Photos"); ?> | O'zBRU</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(route('photos', 'en')); ?>"><img src="/images/icon/1.jpg" alt="JB's Language Icon"><span>En</span></a>
    </li>
    <li>
        <a href="<?php echo e(route('photos', 'ru')); ?>"><img src="/images/icon/2.jpg" alt="JB's Language Icon"><span>Ru</span></a>
    </li>
    <li>
        <a href="<?php echo e(route('photos', 'uz')); ?>"><img src="/images/icon/3.jpg" alt="JB's Language Icon"><span>Uz</span></a>
    </li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mob-lang'); ?>
<a href="<?php echo e(route('photos', 'en')); ?>" style="color: white;"><img src="/images/icon/1.jpg" alt="JB's Language Icon"><span>En</span></a>
<a href="<?php echo e(route('photos', 'ru')); ?>" style="color: white; padding-left: 15px;"><img src="/images/icon/2.jpg" alt="JB's Language Icon"><span>Ru</span></a>
<a href="<?php echo e(route('photos', 'uz')); ?>" style="color: white; padding-left: 15px;"><img src="/images/icon/3.jpg" alt="JB's Language Icon"><span>Uz</span></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="no-padding sh-about">
    <div class="sub-header ">
        <span><?php echo app('translator')->get("Uzbekistan Business Development Association"); ?></span>
        <h3><?php echo app('translator')->get("Photos"); ?></h3>
        <ol class="breadcrumb">
             <li>
                <a href="<?php echo e(route('home', app()->getLocale())); ?>"><i class="fa fa-home"></i> <?php echo app('translator')->get("Main"); ?></a>
             </li>
             <li>
                 <a href="javascript:void()"><?php echo app('translator')->get("Media"); ?></a>
             </li>
             <li class="active"><?php echo app('translator')->get("Photos"); ?></li>
         </ol>
    </div>
</section>

<section>
    <div class="container">
        <div class="row">

            

            <div class="cases-warp cases-warp-h5 cases-warp-page">
                <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="element-item Tokyo Funds">
                        <div class="item-project">
                            <img src="/storage/<?php echo e($item->image1); ?>" class="img-responsive" alt="Image">
                            <div class="overlay-project">
                                <h4><a href="javascript:void()"><?php echo e($item->title); ?></a></h4>
                                <a class="cate" href="javascript:void()"><?php echo e($item->body); ?></a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
            </div>
            
            <?php echo e($photos->links()); ?>

        </div>
    </div>
</section>
<!-- /Cases -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/UzBRU/resources/views/media/photo.blade.php ENDPATH**/ ?>