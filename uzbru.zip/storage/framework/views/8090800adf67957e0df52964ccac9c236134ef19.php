<!-- Mobile Menu -->
<nav id="menu">
    <ul>
        <div class="row text-center" style=" margin: 15px; padding-left: 5px;" >
            <li >
                <?php echo $__env->yieldContent('mob-lang'); ?>
            </li>
        </div>
        <li class="active">
            <a href="<?php echo e(route('home', app()->getLocale())); ?>"><?php echo app('translator')->get("Main"); ?></a>
        </li>
        <li><a href="<?php echo e(route('association', app()->getLocale())); ?>"><?php echo app('translator')->get("Association"); ?></a>
            <ul >

                <li><a href="<?php echo e(route('association', app()->getLocale())); ?>" ><span><?php echo app('translator')->get("History"); ?></span></a>
                </li>
                <li><a href="<?php echo e(route('about', app()->getLocale())); ?>" ><span><?php echo app('translator')->get("About Us"); ?></span></a>
                </li>
                <li><a href="<?php echo e(route('services', app()->getLocale())); ?>" ><span><?php echo app('translator')->get("Services"); ?></span></a>
                </li>
                <li><a href="<?php echo e(route('team', app()->getLocale())); ?>" ><span><?php echo app('translator')->get("Staff"); ?></span></a>
                <li><a href="<?php echo e(route('branches', app()->getLocale())); ?>" ><span><?php echo app('translator')->get("Branches"); ?></span></a>
            </ul>
        </li>
        <li>
            <a href="<?php echo e(route('bemember', app()->getLocale())); ?>"><?php echo app('translator')->get("Membership"); ?> </a>
            <ul >
                <li ><a  href="<?php echo e(route('bemember', app()->getLocale())); ?>"><?php echo app('translator')->get("Become a member"); ?></a></li>
                <li ><a  href="<?php echo e(route('members', app()->getLocale())); ?>"><?php echo app('translator')->get("List of members"); ?></a></li>
                <li ><a  href="<?php echo e(route('checkmembers', app()->getLocale())); ?>"><?php echo app('translator')->get("Check for membership"); ?></a></li>
            </ul>
        </li>
        <li>
            <a href="<?php echo e(route('partners', app()->getLocale())); ?>"><?php echo app('translator')->get("Information"); ?></a>
            <ul >
                
                <li><a href="<?php echo e(route('partners', app()->getLocale())); ?>"><?php echo app('translator')->get("Partners"); ?></a></li>
                <li><a href="<?php echo e(route('faq', app()->getLocale())); ?>"><?php echo app('translator')->get("FAQ"); ?></a></li>
            </ul>
        </li>
        <li>
            <a href="<?php echo e(route('news', app()->getLocale())); ?>"><?php echo app('translator')->get("News"); ?></a>
            <ul >
                <li><a href="<?php echo e(route('news', app()->getLocale())); ?>"><?php echo app('translator')->get("General News"); ?></a></li>
                <li ><a  href="<?php echo e(route('association-news', app()->getLocale())); ?>"><?php echo app('translator')->get("Association News"); ?></a></li>
            </ul>
        </li>
        <li>
            <a href="<?php echo e(route('photos', app()->getLocale())); ?>"><?php echo app('translator')->get("Media"); ?></a>
            <ul >
                <li ><a  href="<?php echo e(route('photos', app()->getLocale())); ?>"><?php echo app('translator')->get("Photos"); ?></a></li>
                <li ><a  href="<?php echo e(route('videos', app()->getLocale())); ?>"><?php echo app('translator')->get("Video"); ?></a></li>
                
            </ul>
        </li>
        <li><a href="<?php echo e(route('contacts', app()->getLocale())); ?>"><?php echo app('translator')->get("Contacts"); ?></a></li>
    </ul>
</nav>
<!-- /Mobile Menu -->
<header class="header-3-fix" >
    <div class="nav-warp nav-warp-h3">
        <div class="navi-warp-home-3">
            <a href="<?php echo e(route('home', app()->getLocale())); ?>" class="logo"><img src="/images/Logo-on-dark.png" class="img-responsive" alt="Image"></a>
            
            <div class="tb-social-lan language">
                <a href="tel:+998712070098"><i class="fa fa-phone" aria-hidden="true"></i>+998(71)2070098</a>
                <ul>
                    <?php echo $__env->yieldContent('language'); ?>
                    
                </ul>
                <ul>
                    <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                    <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="twitter"><i class="fa fa-paper-plane" aria-hidden="true"></i></a></li>
                    <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="google plus"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                    <li><a href="#" data-toggle="tooltip" data-placement="bottom" title="youtube"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                </ul>
            </div>
            <nav>
                        <ul class="navi-level-1 active-subcolor">
                            <li class="active">
                                <a href="<?php echo e(route('home', app()->getLocale())); ?>"><?php echo app('translator')->get("Main"); ?></a>
                            </li>
                            <li><a href="<?php echo e(route('association', app()->getLocale())); ?>"><?php echo app('translator')->get("Association"); ?></a>
                                <ul class="navi-level-2">

                                    <li><a href="<?php echo e(route('association', app()->getLocale())); ?>" ><span><?php echo app('translator')->get("History"); ?></span></a>
                                    </li>
                                    <li><a href="<?php echo e(route('about', app()->getLocale())); ?>" ><span><?php echo app('translator')->get("About Us"); ?></span></a>
                                    </li>
                                    <li><a href="<?php echo e(route('services', app()->getLocale())); ?>" ><span><?php echo app('translator')->get("Services"); ?></span></a>
                                    </li>
                                    <li><a href="<?php echo e(route('team', app()->getLocale())); ?>" ><span><?php echo app('translator')->get("Staff"); ?></span></a>
                                    </li>
                                    <li><a href="<?php echo e(route('branches', app()->getLocale())); ?>" ><span><?php echo app('translator')->get("Branches"); ?></span></a>	
                                </ul>
                            </li>
                            <li>
                                <a href="<?php echo e(route('bemember', app()->getLocale())); ?>"><?php echo app('translator')->get("Membership"); ?></a>
                                <ul class="navi-level-2">
                                    <li ><a  href="<?php echo e(route('bemember', app()->getLocale())); ?>"><?php echo app('translator')->get("Become a member"); ?></a></li>
                                    <li ><a  href="<?php echo e(route('members', app()->getLocale())); ?>"><?php echo app('translator')->get("List of members"); ?></a></li>
                                    <li ><a  href="<?php echo e(route('checkmembers', app()->getLocale())); ?>"><?php echo app('translator')->get("Check for membership"); ?></a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="<?php echo e(route('partners', app()->getLocale())); ?>"><?php echo app('translator')->get("Information"); ?></a>
                                <ul class="navi-level-2">
                                    
                                    <li><a href="<?php echo e(route('partners', app()->getLocale())); ?>"><?php echo app('translator')->get("Partners"); ?></a></li>
                                    <li><a href="<?php echo e(route('faq', app()->getLocale())); ?>"><?php echo app('translator')->get("FAQ"); ?></a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="<?php echo e(route('news', app()->getLocale())); ?>"><?php echo app('translator')->get("News"); ?></a>
                                <ul class="navi-level-2">
                                    <li><a href="<?php echo e(route('news', app()->getLocale())); ?>"><?php echo app('translator')->get("General News"); ?></a></li>
                                    <li ><a  href="<?php echo e(route('association-news', app()->getLocale())); ?>"><?php echo app('translator')->get("Association News"); ?></a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="<?php echo e(route('photos', app()->getLocale())); ?>"><?php echo app('translator')->get("Media"); ?></a>
                                <ul class="navi-level-2">
                                    
                                    <li ><a  href="<?php echo e(route('photos', app()->getLocale())); ?>"><?php echo app('translator')->get("Photos"); ?></a></li>
                                    <li ><a  href="<?php echo e(route('videos', app()->getLocale())); ?>"><?php echo app('translator')->get("Video"); ?></a></li>
                                </ul>
                            </li>
                            <li><a href="<?php echo e(route('contacts', app()->getLocale())); ?>"><?php echo app('translator')->get("Contacts"); ?></a></li>
                        </ul>
                    </nav>
            <a href="#menu" class="btn-menu-mobile"><i class="fa fa-bars" aria-hidden="true"></i></a>
        </div>
    </div>
    <!-- /nav -->
</header><?php /**PATH /opt/lampp/htdocs/UzBRU/resources/views/inc/header.blade.php ENDPATH**/ ?>