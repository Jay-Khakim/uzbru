<?php $__env->startSection('title'); ?>
<title><?php echo app('translator')->get("List of members"); ?> | O'zBRU</title>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(route('members', 'en')); ?>"><img src="/images/icon/1.jpg" alt="JB's Language Icon"><span>En</span></a>
    </li>
    <li>
        <a href="<?php echo e(route('members', 'ru')); ?>"><img src="/images/icon/2.jpg" alt="JB's Language Icon"><span>Ru</span></a>
    </li>
    <li>
        <a href="<?php echo e(route('members', 'uz')); ?>"><img src="/images/icon/3.jpg" alt="JB's Language Icon"><span>Uz</span></a>
    </li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mob-lang'); ?>
<a href="<?php echo e(route('members', 'en')); ?>" style="color: white;"><img src="/images/icon/1.jpg" alt="JB's Language Icon"><span>En</span></a>
<a href="<?php echo e(route('members', 'ru')); ?>" style="color: white; padding-left: 15px;"><img src="/images/icon/2.jpg" alt="JB's Language Icon"><span>Ru</span></a>
<a href="<?php echo e(route('members', 'uz')); ?>" style="color: white; padding-left: 15px;"><img src="/images/icon/3.jpg" alt="JB's Language Icon"><span>Uz</span></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="no-padding sh-company-history">
    <div class="sub-header ">
        <span><?php echo app('translator')->get("Uzbekistan Business Development Association"); ?></span>
        <h3><?php echo app('translator')->get("List of members"); ?></h3>
        <ol class="breadcrumb">
             <li>
                <a href="<?php echo e(route('home', app()->getLocale())); ?>"><i class="fa fa-home"></i> <?php echo app('translator')->get("Main"); ?></a>
             </li>
             <li>
                 <a href="<?php echo e(route('bemember', app()->getLocale())); ?>"><?php echo app('translator')->get("Membership"); ?></a>
             </li>
             <li class="active"><?php echo app('translator')->get("List of members"); ?></li>
         </ol>
    </div>
</section>
<!-- /Sub HEader -->

<section>
    <div class="container">
        <div class="row">
            <div class="shop-page-warp">
                <div class="col-md-12">
                    <div class="group-title-btn">
                        <div class="title-block">
                            <h3><?php echo app('translator')->get("List of members"); ?></h3>
                            <span class="bottom-title"></span>
                        </div>
                    </div>
                </div>
                <div class="list-product">
                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 col-sm-6">
                            <div class="product-item">
                                <figure >
                                    <a href="<?php echo e(route('single-member', [app()->getLocale(), $member->id])); ?>">
                                        <img src="/storage/<?php echo e($member->image); ?>" class="img-responsive" alt="Image">
                                    </a>
                                </figure>
                                <div class="product-detail">
                                    <h3 align="center"><a href="<?php echo e(route('single-member', [app()->getLocale(), $member->id])); ?>"><?php echo e($member->name); ?></a></h3>
                                    <span class="price">
                                        <?php if($member->status == "active"): ?>
                                            <span class="amount" style="color: green"><?php echo app('translator')->get("Status"); ?>: <?php echo e($member->status); ?></span> 
                                            
                                        <?php endif; ?>
                                        <?php if($member->status == "inactive"): ?>
                                            <span class="amount" style="color: red"><?php echo app('translator')->get("Status"); ?>: <?php echo e($member->status); ?></span> 
                                            
                                        <?php endif; ?>
                                    </span>
                                
                                </div>
                                <div class="btn">
                                    <a href="<?php echo e(route('single-member', [app()->getLocale(), $member->id])); ?>" class="ot-btn btn-main-color">
                                    <i class="fa fa-eye" aria-hidden="true"></i> <?php echo app('translator')->get("More"); ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php echo e($members->links()); ?>


                
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/UzBRU/resources/views/membership/members.blade.php ENDPATH**/ ?>