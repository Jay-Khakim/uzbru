<?php $__env->startSection('title'); ?>
    <title><?php echo app('translator')->get("Video"); ?> | O'zBRU</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(route('videos', 'en')); ?>"><img src="/images/icon/1.jpg" alt="JB's Language Icon"><span>En</span></a>
    </li>
    <li>
        <a href="<?php echo e(route('videos', 'ru')); ?>"><img src="/images/icon/2.jpg" alt="JB's Language Icon"><span>Ru</span></a>
    </li>
    <li>
        <a href="<?php echo e(route('videos', 'uz')); ?>"><img src="/images/icon/3.jpg" alt="JB's Language Icon"><span>Uz</span></a>
    </li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mob-lang'); ?>
<a href="<?php echo e(route('videos', 'en')); ?>" style="color: white;"><img src="/images/icon/1.jpg" alt="JB's Language Icon"><span>En</span></a>
<a href="<?php echo e(route('videos', 'ru')); ?>" style="color: white; padding-left: 15px;"><img src="/images/icon/2.jpg" alt="JB's Language Icon"><span>Ru</span></a>
<a href="<?php echo e(route('videos', 'uz')); ?>" style="color: white; padding-left: 15px;"><img src="/images/icon/3.jpg" alt="JB's Language Icon"><span>Uz</span></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="no-padding sh-about">
    <div class="sub-header ">
        <span><?php echo app('translator')->get("Uzbekistan Business Development Association"); ?></span>
        <h3><?php echo app('translator')->get("Video"); ?></h3>
        <ol class="breadcrumb">
             <li>
                <a href="<?php echo e(route('home', app()->getLocale())); ?>"><i class="fa fa-home"></i> <?php echo app('translator')->get("Main"); ?></a>
             </li>
             <li>
                <a href="javascript:void()"><?php echo app('translator')->get("Media"); ?></a>
             </li>
             <li class="active"><?php echo app('translator')->get("Video"); ?></li>
         </ol>
    </div>
</section>
    
<section>
    <div class="container">
        <div class="row">
            <div class="news-list-warp">
                <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <div class="item-new-list grid-new">
                    <div class="feature-new-warp">
                        <img src="/storage/<?php echo e($item->image1); ?>" alt="Image">
                        <a href="<?php echo e($item->link); ?>" class="popup-youtube">
                            <img src="/images/About/Play.png" class="img-responsive btn-play-new" alt="Image">
                        </a>
                    </div>
                    <div class="box-new-info">
                        <div class="new-info">
                            <h4>
                                <a href="single_new.html"><?php echo e($item->title); ?></a>
                            </h4>
                            <p><i class="fa fa-calendar" aria-hidden="true"></i><?php echo e($item->created_at->format('d')); ?>

                                <?php if($item->created_at->format('m') == 1): ?>
                                    <?php echo app('translator')->get("Jan"); ?>
                                <?php endif; ?>
                                <?php if($item->created_at->format('m') == 2): ?>
                                    <?php echo app('translator')->get("Feb"); ?>
                                <?php endif; ?>
                                <?php if($item->created_at->format('m') == 3): ?>
                                    <?php echo app('translator')->get("Mar"); ?>
                                <?php endif; ?>
                                <?php if($item->created_at->format('m') == 4): ?>
                                    <?php echo app('translator')->get("Apr"); ?>
                                <?php endif; ?>
                                <?php if($item->created_at->format('m') == 5): ?>
                                    <?php echo app('translator')->get("May"); ?>
                                <?php endif; ?>
                                <?php if($item->created_at->format('m') == 6): ?>
                                    <?php echo app('translator')->get("Jun"); ?>
                                <?php endif; ?>
                                <?php if($item->created_at->format('m') == 7): ?>
                                    <?php echo app('translator')->get("Jul"); ?>
                                <?php endif; ?>
                                <?php if($item->created_at->format('m') == 8): ?>
                                    <?php echo app('translator')->get("Aug"); ?>
                                <?php endif; ?>
                                <?php if($item->created_at->format('m') == 9): ?>
                                    <?php echo app('translator')->get("Sep"); ?>
                                <?php endif; ?>
                                <?php if($item->created_at->format('m') == 10): ?>
                                    <?php echo app('translator')->get("Oct"); ?>
                                <?php endif; ?>
                                <?php if($item->created_at->format('m') == 11): ?>
                                    <?php echo app('translator')->get("Nov"); ?>
                                <?php endif; ?>
                                <?php if($item->created_at->format('m') == 12): ?>
                                    <?php echo app('translator')->get("Dec"); ?>
                                <?php endif; ?>,
                                <?php echo e($item->created_at->format('Y')); ?></p>
                                <?php if($item->author): ?>
                                    <p><i class="fa fa-user" aria-hidden="true"></i><?php echo e($item->author); ?></p>
                                <?php else: ?> 
                                    <p><i class="fa fa-user" aria-hidden="true"></i><?php echo app('translator')->get("By Admin"); ?></p>
                                <?php endif; ?>
                            
                        </div>
                        <div class="tapo">
                            <p><?php echo $item->body; ?></p>
                        </div>
                    </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
                
               		
                    
                </div>	
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/UzBRU/resources/views/media/videos.blade.php ENDPATH**/ ?>