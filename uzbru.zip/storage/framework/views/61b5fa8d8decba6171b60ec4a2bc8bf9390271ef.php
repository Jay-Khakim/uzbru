<?php $__env->startSection('title'); ?>
<title><?php echo app('translator')->get("Partners"); ?> | O'zBRU</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(route('partners', 'en')); ?>"><img src="/images/icon/1.jpg" alt="JB's Language Icon"><span>En</span></a>
    </li>
    <li>
        <a href="<?php echo e(route('partners', 'ru')); ?>"><img src="/images/icon/2.jpg" alt="JB's Language Icon"><span>Ru</span></a>
    </li>
    <li>
        <a href="<?php echo e(route('partners', 'uz')); ?>"><img src="/images/icon/3.jpg" alt="JB's Language Icon"><span>Uz</span></a>
    </li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mob-lang'); ?>
<a href="<?php echo e(route('partners', 'en')); ?>" style="color: white;"><img src="/images/icon/1.jpg" alt="JB's Language Icon"><span>En</span></a>
<a href="<?php echo e(route('partners', 'ru')); ?>" style="color: white; padding-left: 15px;"><img src="/images/icon/2.jpg" alt="JB's Language Icon"><span>Ru</span></a>
<a href="<?php echo e(route('partners', 'uz')); ?>" style="color: white; padding-left: 15px;"><img src="/images/icon/3.jpg" alt="JB's Language Icon"><span>Uz</span></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    	
<section class="no-padding sh-about">
    <div class="sub-header ">
        <span><?php echo app('translator')->get("Uzbekistan Business Development Association"); ?></span>
        <h3><?php echo app('translator')->get("Partners"); ?></h3>
        <ol class="breadcrumb">
            <li>
                <a href="<?php echo e(route('home', app()->getLocale())); ?>"><i class="fa fa-home"></i> <?php echo app('translator')->get("Main"); ?></a>
            </li>
            <li>
               <a href="javascript:void()"><?php echo app('translator')->get("Information"); ?></a>
            </li>
            <li class="active"><?php echo app('translator')->get("Partners"); ?></li>
        </ol>
    </div>
</section>

<section>
    <div class="container">
        <div class="row">
            <div class="partner-list">
                
                <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item-partner-list">
                        <div class="col-md-3">
                            <a href="javascript:void()"><img src="/storage/<?php echo e($item->image); ?>" class="img-responsive" alt="Image"></a>
                        </div>
                        <div class="col-md-9">
                            <h4><a href="<?php echo e($item->web); ?>"><?php echo e($item->name); ?></a></h4>
                            <p><span class="pull-left"><?php echo e($item->field); ?></span> <span class="pull-right"><?php echo e($item->address); ?></span></p>
                            <p><?php echo $item->desc; ?></p>
                            <a href="<?php echo e($item->web); ?>" target="_blank" class="ot-btn btn-sub-color"><?php echo app('translator')->get("Visit Website"); ?></a>
                        </div>
                    </div> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
            
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/UzBRU/resources/views/information/partners.blade.php ENDPATH**/ ?>