<?php $__env->startSection('title'); ?>
    <title><?php echo app('translator')->get("Uzbekistan Business Development Association"); ?> | <?php echo app('translator')->get("UBDA"); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(url( 'en')); ?>"><img src="/images/icon/1.jpg" alt="JB's Language Icon"><span>En</span></a>
    </li>
    <li>
        <a href="<?php echo e(url( 'ru')); ?>"><img src="/images/icon/2.jpg" alt="JB's Language Icon"><span>Ru</span></a>
    </li>
    <li>
        <a href="<?php echo e(url( 'uz')); ?>"><img src="/images/icon/3.jpg" alt="JB's Language Icon"><span>Uz</span></a>
    </li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mob-lang'); ?>
<a href="<?php echo e(url( 'en')); ?>" style="color: white;"><img src="/images/icon/1.jpg" alt="JB's Language Icon"><span>En</span></a>
<a href="<?php echo e(url( 'ru')); ?>" style="color: white; padding-left: 15px;"><img src="/images/icon/2.jpg" alt="JB's Language Icon"><span>Ru</span></a>
<a href="<?php echo e(url( 'uz')); ?>" style="color: white; padding-left: 15px;"><img src="/images/icon/3.jpg" alt="JB's Language Icon"><span>Uz</span></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Slider -->
<section id="slider" class="no-padding">
    <div id="slide_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container">
        <!-- START REVOLUTION SLIDER 5.0.7 auto mode -->
        <div id="slider_3" class="rev_slider fullwidthabanner slider-home1" style="display:none;" data-version="5.0.7">
            <ul>
                <!-- SLIDE  -->
                <li data-title="FOCUS ON">
                    <!-- MAIN IMAGE -->
                    <img src="/images/Slider/home3/1.jpg"  alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
                    <!-- LAYERS -->
                    <!-- LAYER NR. 0 -->
                    <div class="tp-caption tp-resizeme" 
                         data-x="right" data-hoffset="" 
                         data-y="bottom" data-voffset=""
                         data-width="['580','580','580','auto']" 
                        data-transform_idle="o:1;"
                        data-transform_in="x:550px;opacity:0;s:800;e:Power3.easeOut;" 
                         data-transform_out="x:550px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 
                        data-start="1000" 

                        data-responsive_offset="on" 
                        ><img src="/images/Slider/home3/people1.png" class="img-responsive hidden-sm hidden-xs" alt="Image">
                    </div>
                    <!-- LAYER NR. 1 -->
                    <div class="tp-caption tp-resizeme sl-s5" 
                         data-x="left" data-hoffset="0" 
                         data-y="center" data-voffset="-45"
                         data-width="['400','400','400','300']" 
                        data-transform_idle="o:1;"
                        data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
                         data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"  
                        data-start="1700" 
                        data-whitespace="normal"
                        data-fontsize="['60','60','60','30']"
                        data-lineheight="['70','70','70','50']"
                        data-responsive_offset="on" 
                        >
                        <p><?php echo app('translator')->get("Entrepreneurship <span> Activity </span> Development"); ?></p>
                    </div>
                    <!-- LAYER NR. 2 -->
                    <div class="tp-caption tp-resizeme" 
                         data-x="left" data-hoffset="0" 
                         data-y="center" data-voffset="65" 
                         data-width="['580','580','480','300']"
                        data-transform_idle="o:1;"
                        data-whitespace=normal
                        data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
                         data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                        data-start="1900" 
                        data-responsive_offset="on" 
                        ><p class="sl-s3 mt-2"><?php echo app('translator')->get("Uzbekistan Business Development Association"); ?></p>
                    </div>
                    <!-- LAYER NR. 3 -->
                    <div class="tp-caption" 
                         data-x="left" data-hoffset="0" 
                         data-y="bottom" data-voffset="180" 
                        data-transform_idle="o:1;"
                        data-actions='[{"event":"click", "action":"jumptoslide", "slide":"prev", "delay":""}]' 
                        data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
                         data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                        data-start="2100" 
                        ><a href="#" class="sl-btn-prev"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
                    </div>
                    <!-- LAYER NR. 4 -->
                    <div class="tp-caption" 
                         data-x="left" data-hoffset="70" 
                         data-y="bottom" data-voffset="180" 
                        data-transform_idle="o:1;"
                        data-actions='[{"event":"click", "action":"jumptoslide", "slide":"next", "delay":""}]' 
                        data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
                         data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                        data-start="2100" 
                        ><a href="#" class="sl-btn-next"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
                    </div>
                </li>
                <!-- SLIDE  -->
                <li data-title="FOCUS ON">
                    <!-- MAIN IMAGE -->
                    <img src="/images/Slider/home3/2.jpg"  alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
                    <!-- LAYERS -->
                    <!-- LAYER NR. 0 -->
                    <div class="tp-caption tp-resizeme" 
                         data-x="right" data-hoffset="" 
                         data-y="bottom" data-voffset=""
                         data-width="['580','580','580','auto']" 
                        data-transform_idle="o:1;"
                        data-transform_in="x:550px;opacity:0;s:800;e:Power3.easeOut;" 
                         data-transform_out="x:550px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 
                        data-start="1000" 

                        data-responsive_offset="on" 
                        ><img src="/images/Slider/home3/people2.png" class="img-responsive hidden-sm hidden-xs" alt="Image">
                    </div>
                    <!-- LAYER NR. 1 -->
                    <div class="tp-caption tp-resizeme sl-s5" 
                         data-x="left" data-hoffset="0" 
                         data-y="center" data-voffset="-45"
                         data-width="['400','400','400','300']" 
                        data-transform_idle="o:1;"
                        data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
                         data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"  
                        data-start="1700" 
                        data-whitespace="normal"
                        data-fontsize="['60','60','60','30']"
                        data-lineheight="['70','70','70','50']"
                        data-responsive_offset="on" 
                        >
                        <p><?php echo app('translator')->get("BUSINESS <SPAN> SUPPORT </span>"); ?></p>
                    </div>
                    <!-- LAYER NR. 2 -->
                    <div class="tp-caption tp-resizeme" 
                         data-x="left" data-hoffset="0" 
                         data-y="center" data-voffset="65" 
                         data-width="['580','580','480','300']"
                        data-transform_idle="o:1;"
                        data-whitespace=normal
                        data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
                         data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                        data-start="1900" 
                        data-responsive_offset="on" 
                        ><p class="sl-s3 mt-2"><?php echo app('translator')->get("Uzbekistan Business Development Association"); ?></p>
                    </div>
                    <!-- LAYER NR. 3 -->
                    <div class="tp-caption" 
                         data-x="left" data-hoffset="0" 
                         data-y="bottom" data-voffset="180" 
                        data-transform_idle="o:1;"
                        data-actions='[{"event":"click", "action":"jumptoslide", "slide":"prev", "delay":""}]' 
                        data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
                         data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                        data-start="2100" 
                        ><a href="#" class="sl-btn-prev"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
                    </div>
                    <!-- LAYER NR. 4 -->
                    <div class="tp-caption" 
                         data-x="left" data-hoffset="70" 
                         data-y="bottom" data-voffset="180" 
                        data-transform_idle="o:1;"
                        data-actions='[{"event":"click", "action":"jumptoslide", "slide":"next", "delay":""}]' 
                        data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
                         data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                        data-start="2100" 
                        ><a href="#" class="sl-btn-next"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
                    </div>
                </li>
                <!-- SLIDE  -->
                <li data-title="FOCUS ON">
                    <!-- MAIN IMAGE -->
                    <img src="images/Slider/home3/3.jpg"  alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
                    <!-- LAYERS -->
                    <!-- LAYER NR. 0 -->
                    <div class="tp-caption tp-resizeme" 
                         data-x="right" data-hoffset="" 
                         data-y="bottom" data-voffset=""
                         data-width="['580','580','580','auto']" 
                        data-transform_idle="o:1;"
                        data-transform_in="x:550px;opacity:0;s:800;e:Power3.easeOut;" 
                         data-transform_out="x:550px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 
                        data-start="1000" 

                        data-responsive_offset="on" 
                        ><img src="/images/Slider/home3/people3.png" class="img-responsive hidden-sm hidden-xs" alt="Image">
                    </div>
                    <!-- LAYER NR. 1 -->
                    <div class="tp-caption tp-resizeme sl-s5" 
                         data-x="left" data-hoffset="0" 
                         data-y="center" data-voffset="-45"
                         data-width="['400','400','400','300']" 
                        data-transform_idle="o:1;"
                        data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
                         data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"  
                        data-start="1700" 
                        data-whitespace="normal"
                        data-fontsize="['60','60','60','30']"
                        data-lineheight="['70','70','70','50']"
                        data-responsive_offset="on" 
                        ><p><?php echo app('translator')->get("A trusted <span>Business</span> Partner"); ?></p>
                    </div>
                    <!-- LAYER NR. 2 -->
                    <div class="tp-caption tp-resizeme" 
                         data-x="left" data-hoffset="0" 
                         data-y="center" data-voffset="65" 
                         data-width="['580','580','480','300']"
                        data-transform_idle="o:1;"
                        data-whitespace=normal
                        data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
                         data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                        data-start="1900" 
                        data-responsive_offset="on" 
                        >
                        <br><p class="sl-s3 mt-2"><?php echo app('translator')->get("Uzbekistan Business Development Association"); ?></p>
                    </div>
                    <!-- LAYER NR. 3 -->
                    <div class="tp-caption" 
                         data-x="left" data-hoffset="0" 
                         data-y="bottom" data-voffset="180" 
                        data-transform_idle="o:1;"
                        data-actions='[{"event":"click", "action":"jumptoslide", "slide":"prev", "delay":""}]' 
                        data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
                         data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                        data-start="2100" 
                        ><a href="#" class="sl-btn-prev"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
                    </div>
                    <!-- LAYER NR. 4 -->
                    <div class="tp-caption" 
                         data-x="left" data-hoffset="70" 
                         data-y="bottom" data-voffset="180" 
                        data-transform_idle="o:1;"
                        data-actions='[{"event":"click", "action":"jumptoslide", "slide":"next", "delay":""}]' 
                        data-transform_in="x:100px;opacity:0;s:800;e:Power3.easeOut;" 
                         data-transform_out="x:-100px;opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                        data-start="2100" 
                        ><a href="#" class="sl-btn-next"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</section>
<!-- /Slider -->

<section class="no-padding">
    <div class="container">
        <div class="row">
            <div class="whyus-warp-h2 core-value-h3">
                <div class="col-md-6">
                    <div class="left-whyus-h2">
                        <div class="demo-style-1-warp">
                            <img src="/images/Content/bg-core-value-h3.png" class="img-responsive" alt="Image">
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="right-whyus-h2">
                        <div class="iconbox-warp ">
                            <div class="title-block">
                                <span class="top-title"></span>
                                <h2><?php echo app('translator')->get("About Us"); ?></h2>
                                <p class="sub-title"><?php echo app('translator')->get("We grow your business together"); ?>!</p>
                                <span class="bottom-title"></span>
                            </div>
                            <p class="demo-sub-about-text"><?php echo app('translator')->get("In order to ensure the implementation of the Decree of the President of the Republic of Uzbekistan dated 03.04.2020 'On additional measures to support the population, sectors of the economy and businesses during the coronavirus pandemic' 'Association Business Development of Uzbekistan' was established"); ?>.</p>
                            <h4><?php echo app('translator')->get("The basis of the association"); ?></h4>
                            <p><?php echo app('translator')->get("The association was registered by the Ministry of Justice on October 26, 2020 with the registration number №309"); ?>.</p>
                            <h4><?php echo app('translator')->get("Chairman of the Association"); ?></h4>
                            <p><?php echo app('translator')->get("Malikov Yorkinjon Erkinjonovich, Chairman of the Board of the Business Development Association of Uzbekistan"); ?>.</p>
                            <h4><?php echo app('translator')->get("The purpose of the association"); ?></h4>
                            <p><?php echo app('translator')->get("Support of entrepreneurs in our country, implementation of active transformation processes of entrepreneurs to world business standards, assistance in reducing the shadow economy, transformation of business entities into the digital economy"); ?>.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- about description -->

<section class="no-padding offer-h10">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="title-block text-center title-pd">
                    <span class="top-title "></span>
                    <h2><?php echo app('translator')->get("Our Advantages"); ?></h2>
                    <p class="sub-title"><?php echo app('translator')->get("As always, partners grows with you"); ?>!</p>
                    <span class="bottom-title"></span>
                </div>
                <div class="warp-full-width services-h1-warp offer-h10-warp">
                <div class="col-md-4 col-sm-6">
                    <div class="item-offer-h10" >
                        <div class="iconbox-type-xs  text-center">
                            <span class="lnr lnr-pie-chart"></span>
                            <h4><?php echo app('translator')->get("Taxation"); ?></h4>
                            <p><?php echo app('translator')->get("The lysine contingency it's intended to prevent the spread of the animals is case they ever got off the island. Dr. Wu inserted a gene that makes a single faulty enzyme"); ?>.</p>
                            
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="item-offer-h10 bg-light-grey" >
                        <div class="iconbox-type-xs text-center">
                            <span class="lnr lnr-calendar-full"></span>
                            <h4>Accumulation</h4>
                            <p>The lysine contingency it's intended to prevent the spread of the animals is case they ever got off the island. Dr. Wu inserted a gene that makes a single faulty enzyme.</p>
                            
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="item-offer-h10" >
                        <div class="iconbox-type-xs text-center">
                            <span class="lnr lnr-briefcase"></span>
                            <h4>Business Planning</h4>
                            <p>The lysine contingency it's intended to prevent the spread of the animals is case they ever got off the island. Dr. Wu inserted a gene that makes a single faulty enzyme.</p>
                            
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="item-offer-h10 bg-light-grey" >
                        <div class="iconbox-type-xs text-center">
                            <span class="lnr lnr-layers"></span> 
                            <h4>Risk Management</h4>
                            <p>The lysine contingency it's intended to prevent the spread of the animals is case they ever got off the island. Dr. Wu inserted a gene that makes a single faulty enzyme.</p>
                            
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="item-offer-h10" >
                        <div class="iconbox-type-xs text-center">
                            <span class="lnr lnr-pie-chart"></span>
                            <h4>Taxation</h4>
                            <p>The lysine contingency it's intended to prevent the spread of the animals is case they ever got off the island. Dr. Wu inserted a gene that makes a single faulty enzyme.</p>
                            
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="item-offer-h10 bg-light-grey" >
                        <div class="iconbox-type-xs text-center">
                            <span class="lnr lnr-calendar-full"></span>
                            <h4>Accumulation</h4>
                            <p>The lysine contingency it's intended to prevent the spread of the animals is case they ever got off the island. Dr. Wu inserted a gene that makes a single faulty enzyme.</p>
                            
                        </div>
                    </div>
                </div>
                </div>
            </div>
            <div class="col-md-12 text-center">
                <a href="cases.html" class="ot-btn btn-border-dark-color"><?php echo app('translator')->get("All"); ?></a>
            </div>
        </div>
    </div>
</section>
<!-- /Offer -->

<section class="no-padding bg-counter-h1">
    <div class="container">
        <div class="row">
            <div class="warp-counter">
                <div class="col-md-3 col-sm-6">
                    <div class="counter-inline">
                        <span class="icon icon-stats-bars"></span>
                        <span class="counter">460</span>
                        <p><?php echo app('translator')->get("Solved problems"); ?></p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="counter-inline">
                        <span class="icon icon-users"></span>
                        <span class="counter">290</span>
                        <p><?php echo app('translator')->get("Members"); ?></p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="counter-inline">
                        <span class="icon icon-trophy"></span>
                        <span class="counter">18</span>
                        <p><?php echo app('translator')->get("Achievements"); ?></p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="counter-inline">
                        <span class="icon icon-library"></span>
                        <span class="counter">50</span>
                        <p><?php echo app('translator')->get("Partners"); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- couterup -->

<section>
    <div class="container">
        <div class="row">
            <div class="title-block text-center">
                <span class="top-title "></span>
                <h2><?php echo app('translator')->get("Functions of the Association"); ?></h2>
                <p class="sub-title"><?php echo app('translator')->get("Tasks of the Business Development Association of Uzbekistan"); ?></p>
                <span class="bottom-title"></span>
            </div>
            <div class="whyus-warp-h3">
                <div class="col-md-4">
                    <div class="iconbox-inline">
                        <span class="icon icon-trophy"></span>
                        <h4><?php echo app('translator')->get("Business development"); ?></h4>
                        <p><?php echo app('translator')->get("Carry out in-depth marketing research and analysis in order to develop the business and identify appropriate measures based on their results"); ?></p>
                    </div>
                    <div class="iconbox-inline">
                        <span class="icon icon-library"></span>
                        <h4><?php echo app('translator')->get("Assisting the government"); ?></h4>
                        <p><?php echo app('translator')->get("Assist the government in reducing the shadow economy and similar issues"); ?></p>
                    </div>
                    <div class="iconbox-inline">
                        <span class="icon icon-user-check"></span>
                        <h4><?php echo app('translator')->get("Merge members"); ?></h4>
                        <p><?php echo app('translator')->get("To unite the members of the Association, to coordinate their activities, and to protect them"); ?></p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="iconbox-inline">
                            <span class="icon icon-profile"></span>
                            <h4><?php echo app('translator')->get("Add an offer"); ?></h4>
                            <p><?php echo app('translator')->get("Make suggestions for changes to existing laws and regulations as needed to address existing issues"); ?>.</p>
                    </div>
                    <div class="iconbox-inline">
                        <span class="icon icon-briefcase"></span>
                        <h4><?php echo app('translator')->get("Coordination of activities"); ?></h4>
                        <p><?php echo app('translator')->get("Coordinating the investment, commercial, scientific, technical and economic activities of its members"); ?>.</p>
                    </div>
                    <div class="iconbox-inline">
                        <span class="icon icon-rocket"></span>
                        <h4><?php echo app('translator')->get("Capacity building"); ?></h4>
                        <p><?php echo app('translator')->get("Study and promote the experience of developed countries in business capacity building"); ?>.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="iconbox-inline">
                        <span class="icon icon-power"></span>
                        <h4><?php echo app('translator')->get("Marketing research"); ?></h4>
                        <p><?php echo app('translator')->get("Carry out in-depth marketing research and analysis in order to develop the business and identify appropriate measures based on their results"); ?></p>
                    </div>
                    <div class="iconbox-inline">
                        <span class="icon icon-key"></span>
                        <h4><?php echo app('translator')->get("Organizational support"); ?></h4>
                        <p><?php echo app('translator')->get("Close assistance in organizing exhibitions and various business forums at home and abroad"); ?></p>
                    </div>
                    <div class="iconbox-inline">
                        <span class="icon icon-shield"></span>
                        <h4><?php echo app('translator')->get("Helping with problems"); ?></h4>
                        <p><?php echo app('translator')->get("Investigate the problems of its members' businesses and identify solutions"); ?></p>
                    </div>
                </div>	
            </div>
        </div>
    </div>
</section>
<!-- /Why Choose Us -->

<section class="bg-plan-h5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="group-title-btn">
                    <div class="title-block">
                        <span class="top-title"></span>
                        <h2><?php echo app('translator')->get("The principle of association"); ?></h2>
                        <p class="sub-title"><?php echo app('translator')->get("As always, partners grows with you"); ?>!</p>
                        <span class="bottom-title"></span>
                    </div>
                    <div class="customNavigation">
                        <a class="btn-3 btn-3-prev prev-step"><i class="fa fa-angle-left"></i></a>
                        <a class="btn-3 btn-3-next next-step"><i class="fa fa-angle-right"></i></a>
                    </div><!-- End owl button -->
                </div>
                <div class="plan-warp-h5">
                    <div id="plan-h5" class="owl-plan-h5">
                        <div class="item-plan-step">

                            <div class="step">1</div>
                            <h4><?php echo app('translator')->get("Establish"); ?></h4>
                            <p>The lysine contingency it's intended to prevent the spread of the animals is case they ever got off the island. </p>
                        </div>

                        <div class="item-plan-step">
                            
                            <div class="step">2</div>
                            <h4><?php echo app('translator')->get("Collect"); ?></h4>
                            <p>The lysine contingency it's intended to prevent the spread of the animals is case they ever got off the island. </p>
                        </div>

                        <div class="item-plan-step">
                            
                            <div class="step">3</div>
                            <h4><?php echo app('translator')->get("Analyze"); ?></h4>
                            <p>The lysine contingency it's intended to prevent the spread of the animals is case they ever got off the island. </p>
                        </div>

                        <div class="item-plan-step">
                            
                            <div class="step">4</div>
                            <h4><?php echo app('translator')->get("Develop"); ?></h4>
                            <p>The lysine contingency it's intended to prevent the spread of the animals is case they ever got off the island. </p>
                        </div>

                        <div class="item-plan-step">
                            
                            <div class="step">5</div>
                            <h4><?php echo app('translator')->get("Testing"); ?></h4>
                            <p>The lysine contingency it's intended to prevent the spread of the animals is case they ever got off the island. </p>
                        </div>

                        <div class="item-plan-step">
                            
                            <div class="step">6</div>
                            <h4><?php echo app('translator')->get("Contact"); ?></h4>
                            <p>The lysine contingency it's intended to prevent the spread of the animals is case they ever got off the island. </p>
                        </div>

                        <div class="item-plan-step">
                            
                            <div class="step">7</div>
                            <h4><?php echo app('translator')->get("Result"); ?></h4>
                            <p>The lysine contingency it's intended to prevent the spread of the animals is case they ever got off the island. </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /Planning -->



<!-- /call back -->

<section class="no-padding">
    <div class="container">
        <div class="row">
            <div class="title-block text-center title-pd">
                <span class="top-title "></span>
                <h2><?php echo app('translator')->get("Our partners"); ?></h2>
                <p class="sub-title"><?php echo app('translator')->get("Partners of Uzbekistan Business Development Association"); ?> </p>
                <span class="bottom-title"></span>
            </div>
            <div class="col-md-12">
                <div id="partner-h2" class="owl-partner-h2">
                    <div class="item-partner" >
                        <a href="#"><img src="/images/Partner/1.jpg" class="img-responsive partner-img" alt="Image"></a>							
                    </div>
                    <div class="item-partner" >
                        <a href="#"><img src="/images/Partner/2.jpg" class="img-responsive partner-img" alt="Image"></a>							
                    </div>
                    <div class="item-partner" >
                        <a href="#"><img src="/images/Partner/3.jpg" class="img-responsive partner-img" alt="Image"></a>							
                    </div>
                    <div class="item-partner" >
                        <a href="#"><img src="/images/Partner/4.jpg" class="img-responsive partner-img" alt="Image"></a>							
                    </div>
                    <div class="item-partner" >
                        <a href="#"><img src="/images/Partner/5.jpg" class="img-responsive partner-img" alt="Image"></a>							
                    </div>
                    <div class="item-partner" >
                        <a href="#"><img src="/images/Partner/6.jpg" class="img-responsive partner-img" alt="Image"></a>							
                    </div>
                    <div class="item-partner" >
                        <a href="#"><img src="/images/Partner/7.jpg" class="img-responsive partner-img" alt="Image"></a>							
                    </div>
                    <div class="item-partner" >
                        <a href="#"><img src="/images/Partner/8.jpg" class="img-responsive partner-img" alt="Image"></a>							
                    </div>
                    <div class="item-partner" >
                        <a href="#"><img src="/images/Partner/6.jpg" class="img-responsive partner-img" alt="Image"></a>							
                    </div>
                    <div class="item-partner" >
                        <a href="#"><img src="/images/Partner/7.jpg" class="img-responsive partner-img" alt="Image"></a>							
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /partner -->
<section class="bg-tw-h6">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="testimonial-warp tw-h6">
                    <div id="testimonial-h6" class="owl-testimonial-h6">
                        <div class="item-testimonial-h6 text-center" >
                            <a href="#"><img src="/images/Testimonial/1.jpg" class="img-responsive" alt="Image"></a>							
                        
                            <p>Imagination… What we can easily see is only a small percentage of what is possible. Logistics through innovation, dedication, and technology.</p>
                            <span class="h-line-sm"></span>
                            <span class="name">Fatma Hassan</span>
                        </div>
                        <div class="item-testimonial-h6 text-center" >
                            <a href="#"><img src="/images/Testimonial/2.jpg" class="img-responsive" alt="Image"></a>							
                        
                            <p>Imagination… What we can easily see is only a small percentage of what is possible. Logistics through innovation, dedication, and technology.</p>
                            <span class="h-line-sm"></span>
                            <span class="name">Marion Raven</span>
                        </div>
                        <div class="item-testimonial-h6 text-center" >
                            <a href="#"><img src="/images/Testimonial/3.jpg" class="img-responsive" alt="Image"></a>							
                        
                            <p>Imagination… What we can easily see is only a small percentage of what is possible. Logistics through innovation, dedication, and technology.</p>
                            <span class="h-line-sm"></span>
                            <span class="name">James Staling</span>
                        </div>
                        <div class="item-testimonial-h6 text-center" >
                            <a href="#"><img src="/images/Testimonial/4.jpg" class="img-responsive" alt="Image"></a>							
                        
                            <p>Imagination… What we can easily see is only a small percentage of what is possible. Logistics through innovation, dedication, and technology.</p>
                            <span class="h-line-sm"></span>
                            <span class="name">Adam D. Roger</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /Testimonial -->


<section class="bg-news-h9">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="title-block text-center">
                    <span class="top-title "></span>
                    <h2><?php echo app('translator')->get("News"); ?></h2>
                    <p class="sub-title"><?php echo app('translator')->get("All about association updates"); ?></p>
                    <span class="bottom-title"></span>
                </div>
            </div>
            <div class="warp-full-width news-h9-warp ">
                <div id="news-h9" class="  owl-news-h9">
                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item-new">
                            <a href="single_new.html"><img src="/storage/<?php echo e($item->image1); ?>" class="img-responsive" alt="Image"></a>
                            <div class="new-info">
                                <h4><a href="#"><?php echo e($item->title); ?></a></h4>
                                <p><i class="fa fa-calendar" aria-hidden="true"></i>
                                    <?php if($item->created_at->format('m') == 1): ?>
                                        <?php echo app('translator')->get("Jan"); ?>
                                    <?php endif; ?>
                                    <?php if($item->created_at->format('m') == 2): ?>
                                        <?php echo app('translator')->get("Feb"); ?>
                                    <?php endif; ?>
                                    <?php if($item->created_at->format('m') == 3): ?>
                                        <?php echo app('translator')->get("Mar"); ?>
                                    <?php endif; ?>
                                    <?php if($item->created_at->format('m') == 4): ?>
                                        <?php echo app('translator')->get("Apr"); ?>
                                    <?php endif; ?>
                                    <?php if($item->created_at->format('m') == 5): ?>
                                        <?php echo app('translator')->get("May"); ?>
                                    <?php endif; ?>
                                    <?php if($item->created_at->format('m') == 6): ?>
                                        <?php echo app('translator')->get("Jun"); ?>
                                    <?php endif; ?>
                                    <?php if($item->created_at->format('m') == 7): ?>
                                        <?php echo app('translator')->get("Jul"); ?>
                                    <?php endif; ?>
                                    <?php if($item->created_at->format('m') == 8): ?>
                                        <?php echo app('translator')->get("Aug"); ?>
                                    <?php endif; ?>
                                    <?php if($item->created_at->format('m') == 9): ?>
                                        <?php echo app('translator')->get("Sep"); ?>
                                    <?php endif; ?>
                                    <?php if($item->created_at->format('m') == 10): ?>
                                        <?php echo app('translator')->get("Oct"); ?>
                                    <?php endif; ?>
                                    <?php if($item->created_at->format('m') == 11): ?>
                                        <?php echo app('translator')->get("Nov"); ?>
                                    <?php endif; ?>
                                    <?php if($item->created_at->format('m') == 12): ?>
                                        <?php echo app('translator')->get("Dec"); ?>
                                    <?php endif; ?> 
                                    <?php echo e($item->created_at->format('d')); ?>, <?php echo e($item->created_at->format('Y')); ?></p>
                                <p><i class="fa fa-user" aria-hidden="true"></i><a href="#">
                                    <?php if($item->author): ?>
                                        <?php echo e($item->author); ?>

                                    <?php else: ?> 
                                        <?php echo app('translator')->get("By Admin"); ?>
                                    <?php endif; ?>
                                    </a></p>
                                
                                <p>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star-half-o" aria-hidden="true"></i>
                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div>
        </div>
    </div>
</section>
<!-- /News -->


<section>
    <div class="social-inner social-inner-h2 social-inner-h4">
        <div class="container">
            <div class="col-md-8 col-md-offset-2">
            <img src="/images/Logo-on-light.png" class="img-responsive" alt="Image">
            <p>Temporibus autem quibusdam et aut officiis debitis is aut rerum necessitatibus saepes eveniet ut et seo lage voluptates repudiandae sint et molestiae non mes  for Creating  futures through building preservation. </p>
            <ul class="widget widget-footer widget-footer-social-1 social-hover-defaul">
                <li><a class="facebook" href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                <li><a class="twitter" href="#"><i class="fa fa-paper-plane" aria-hidden="true"></i></a></li>
                <li><a class="google" href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                <li><a class="linkedin" href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                <li><a class="flickr" href="#"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
            </ul>
            </div>
        </div>
    </div>
</section>
<!-- /Social -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/UzBRU/resources/views/index.blade.php ENDPATH**/ ?>