<?php $__env->startSection('title'); ?>
<title><?php echo e($member->name); ?> | O'zBRU</title>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(route('single-member', ['language' => 'en', 'id' => $member->id])); ?>"><img src="/images/icon/1.jpg" alt="JB's Language Icon"><span>En</span></a>
    </li>
    <li>
        <a href="<?php echo e(route('single-member', ['language' => 'ru', 'id' => $member->id])); ?>"><img src="/images/icon/2.jpg" alt="JB's Language Icon"><span>Ru</span></a>
    </li>
    <li>
        <a href="<?php echo e(route('single-member', ['language' => 'uz', 'id' => $member->id])); ?>"><img src="/images/icon/3.jpg" alt="JB's Language Icon"><span>Uz</span></a>
    </li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mob-lang'); ?>
<a href="<?php echo e(route('single-member', ['language' => 'en', 'id' => $member->id])); ?>" style="color: white;"><img src="/images/icon/1.jpg" alt="JB's Language Icon"><span>En</span></a>
<a href="<?php echo e(route('single-member', ['language' => 'ru', 'id' => $member->id])); ?>" style="color: white; padding-left: 15px;"><img src="/images/icon/2.jpg" alt="JB's Language Icon"><span>Ru</span></a>
<a href="<?php echo e(route('single-member', ['language' => 'uz', 'id' => $member->id])); ?>" style="color: white; padding-left: 15px;"><img src="/images/icon/3.jpg" alt="JB's Language Icon"><span>Uz</span></a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="no-padding sh-case-single">
    <div class="sub-header ">
        <span><?php echo app('translator')->get("Uzbekistan Business Development Association"); ?></span>
        <h3><?php echo app('translator')->get("Member of Association"); ?></h3>
        <ol class="breadcrumb">
             <li>
                <a href="<?php echo e(route('home', app()->getLocale())); ?>"><i class="fa fa-home"></i> <?php echo app('translator')->get("Main"); ?></a>
             </li>
             <li>
                <a href="<?php echo e(route('bemember', app()->getLocale())); ?>"><?php echo app('translator')->get("Membership"); ?></a>
             </li>
             <li class="active"><?php echo app('translator')->get("Member of Association"); ?></li>
         </ol>
    </div>
</section>
<!-- /Sub HEader -->

<section>
    <div class="container">
        <div class="row">
            <div class="case-detail-warp">
                <div class="col-md-7">
                    <img src="/storage/<?php echo e($member->image); ?>" class="img-responsive" alt="Image">
                </div>
                <div class="col-md-5">
                    <div class="case-detail-info">
                        <h3><?php echo e($member->name); ?></h3>
                        <p class="case-cate"><?php echo e($member->filed); ?></p>
                        <dl class="dl-horizontal">
                            <dt><?php echo app('translator')->get("Status"); ?></dt>
                            <?php if($member->status == "inactive"): ?>
                                <dd style="color: red"><?php echo e($member->status); ?></dd> 
                            <?php endif; ?>
                            <?php if($member->status == "active"): ?>
                                <dd style="color: green"><?php echo e($member->status); ?></dd> 
                            <?php endif; ?>
                          <dt><?php echo app('translator')->get("Owners Name"); ?></dt>
                          <dd><?php echo e($member->owner); ?></dd>

                          <dt><?php echo app('translator')->get("Location"); ?></dt>
                          <dd><?php echo e($member->address); ?></dd>
                          <dt><?php echo app('translator')->get("Established Year"); ?></dt>
                          <dd><?php echo e($member->year); ?></dd>
                          <dt><?php echo app('translator')->get("Value"); ?></dt>
                          <dd><?php echo e($member->value); ?> $</dd>
                        </dl>
                        
                        
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="row">
                        <div class="box-text-case">
                            <div class="col-md-4">
                            <h4>Solution</h4>
                            <p>The path of the righteous man is beset on all sides iniquities of the selfish and the tyranny of evil men. Blessed is he who, in the name of charity and good will, shepherds weak through the valley of darkness, for he is truly his brother's keeper and the finder of lost children.</p>
                            </div>
                            <div class="col-md-4">
                            <h4>Challenge</h4>
                            <p>The path of the righteous man is beset on all sides iniquities of the selfish and the tyranny of evil men. Blessed is he who, in the name of charity and good will, shepherds weak through the valley of darkness, for he is truly his brother's keeper and the finder of lost children.</p>
                            </div>
                            <div class="col-md-4">
                            <h4>Stratgy</h4>
                            <p>The path of the righteous man is beset on all sides iniquities of the selfish and the tyranny of evil men. Blessed is he who, in the name of charity and good will, shepherds weak through the valley of darkness, for he is truly his brother's keeper and the finder of lost children.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /Case Detail Info -->




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/UzBRU/resources/views/membership/single-member.blade.php ENDPATH**/ ?>