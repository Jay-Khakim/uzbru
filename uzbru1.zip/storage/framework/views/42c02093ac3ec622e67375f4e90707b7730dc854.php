
<?php
    $array = data_get($entry, $column['name']);
    $list[$column['visible_key']] = [];

    // if the isn't using attribute casting, decode it
    if (is_string($array)) {
        $array = json_decode($array);
    }

    if (is_array($array) && count($array)) {
        $list = [];
        foreach ($array as $item) {
            if (isset($item->{$column['visible_key']})) {
                $list[$column['visible_key']][] = $item->{$column['visible_key']};
            } elseif (is_array($item) && isset($item[$column['visible_key']])) {
                $list[$column['visible_key']][] = $item[$column['visible_key']];
            }
        }
    }

    $column['escaped'] = $column['escaped'] ?? true;
?>

<span>
    <?php if(!empty($list)): ?>
        <?php $__currentLoopData = $list[$column['visible_key']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $column['text'] = $text;
                $related_key = $key;
            ?>

            <span class="d-inline-flex">
                <?php echo $__env->renderWhen(!empty($column['wrapper']), 'crud::columns.inc.wrapper_start', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
                    <?php if($column['escaped']): ?>
                        <?php echo e($column['text']); ?>

                    <?php else: ?>
                        <?php echo $column['text']; ?>

                    <?php endif; ?>
                <?php echo $__env->renderWhen(!empty($column['wrapper']), 'crud::columns.inc.wrapper_end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
            
                <?php if(!$loop->last): ?>, <?php endif; ?>
            </span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        -
    <?php endif; ?>
</span>
<?php /**PATH /opt/lampp/htdocs/UzBRU/vendor/backpack/crud/src/resources/views/crud/columns/multidimensional_array.blade.php ENDPATH**/ ?>