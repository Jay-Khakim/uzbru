
<?php
    $value = data_get($entry, $column['name']);

    if( !empty($value) ) {

        // if attribute casting is used, convert to object
        if (is_array($value)) {
            $video = (object)$value;
        } elseif (is_string($value)) {
            $video = json_decode($value);
        } else {
            $video = $value;
        }
        $bgColor = $video->provider == 'vimeo' ? '#00ADEF' : '#DA2724';
    }
?>

<span>
    <?php if( isset($video) ): ?>
    <a target="_blank" href="<?php echo e($video->url); ?>" title="<?php echo e($video->title); ?>" style="background: <?php echo e($bgColor); ?>; color: #fff; display: inline-block; width: 30px; height: 25px; text-align: center; border-top-left-radius: 3px; border-bottom-left-radius: 3px; transform: translateY(-1px);">
        <i class="la la-<?php echo e($video->provider); ?>" style="transform: translateY(2px);"></i>
    </a><img src="<?php echo e($video->image); ?>" alt="<?php echo e($video->title); ?>" style="height: 25px; border-top-right-radius: 3px; border-bottom-right-radius: 3px;" />
    <?php else: ?>
    -
    <?php endif; ?>
</span><?php /**PATH /opt/lampp/htdocs/UzBRU/vendor/backpack/crud/src/resources/views/crud/columns/video.blade.php ENDPATH**/ ?>