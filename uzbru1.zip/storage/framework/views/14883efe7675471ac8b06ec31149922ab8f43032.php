<?php $__env->startSection('title'); ?>
<title><?php echo app('translator')->get("Association News"); ?> | O'zBRU</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('language'); ?>
    <li>
        <a href="<?php echo e(route('association-news', 'en')); ?>"><img src="/images/icon/1.jpg" alt="JB's Language Icon"><span>En</span></a>
    </li>
    <li>
        <a href="<?php echo e(route('association-news', 'ru')); ?>"><img src="/images/icon/2.jpg" alt="JB's Language Icon"><span>Ru</span></a>
    </li>
    <li>
        <a href="<?php echo e(route('association-news', 'uz')); ?>"><img src="/images/icon/3.jpg" alt="JB's Language Icon"><span>Uz</span></a>
    </li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mob-lang'); ?>
<a href="<?php echo e(route('association-news', 'en')); ?>" style="color: white;"><img src="/images/icon/1.jpg" alt="JB's Language Icon"><span>En</span></a>
<a href="<?php echo e(route('association-news', 'ru')); ?>" style="color: white; padding-left: 15px;"><img src="/images/icon/2.jpg" alt="JB's Language Icon"><span>Ru</span></a>
<a href="<?php echo e(route('association-news', 'uz')); ?>" style="color: white; padding-left: 15px;"><img src="/images/icon/3.jpg" alt="JB's Language Icon"><span>Uz</span></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="no-padding sh-news">
    <div class="sub-header ">
        <span><?php echo app('translator')->get("Uzbekistan Business Development Association"); ?></span>
        <h3><?php echo app('translator')->get("News"); ?></h3>
        <ol class="breadcrumb">
             <li>
                <a href="<?php echo e(route('home', app()->getLocale())); ?>"><i class="fa fa-home"></i> <?php echo app('translator')->get("Main"); ?></a>
             </li>
             
             <li class="active"> <?php echo app('translator')->get("News"); ?></li>
         </ol>
    </div>
</section>
<!-- /subheader -->
    
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="news-list-warp">
                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item-new-list "> <!-- add class no-position --> 

                        <div class="feature-new-warp">
                            <a href="<?php echo e(route('single-news', [app()->getLocale(), $single->id])); ?>">
                                <img src="/storage/<?php echo e($single->image1); ?>" alt="Image">
                            </a>
                        </div>
                        <div class="box-new-info">
                            <div class="new-info">
                                <h4>
                                    <a href="<?php echo e(route('single-news', [app()->getLocale(), $single->id])); ?>"><?php echo e($single->title); ?></a>
                                </h4>
                                <p><i class="fa fa-calendar" aria-hidden="true"></i><?php echo e($single->created_at->format('d')); ?>

                                <?php if($single->created_at->format('m') == 1): ?>
                                    <?php echo app('translator')->get("Jan"); ?>
                                <?php endif; ?>
                                <?php if($single->created_at->format('m') == 2): ?>
                                    <?php echo app('translator')->get("Feb"); ?>
                                <?php endif; ?>
                                <?php if($single->created_at->format('m') == 3): ?>
                                    <?php echo app('translator')->get("Mar"); ?>
                                <?php endif; ?>
                                <?php if($single->created_at->format('m') == 4): ?>
                                    <?php echo app('translator')->get("Apr"); ?>
                                <?php endif; ?>
                                <?php if($single->created_at->format('m') == 5): ?>
                                    <?php echo app('translator')->get("May"); ?>
                                <?php endif; ?>
                                <?php if($single->created_at->format('m') == 6): ?>
                                    <?php echo app('translator')->get("Jun"); ?>
                                <?php endif; ?>
                                <?php if($single->created_at->format('m') == 7): ?>
                                    <?php echo app('translator')->get("Jul"); ?>
                                <?php endif; ?>
                                <?php if($single->created_at->format('m') == 8): ?>
                                    <?php echo app('translator')->get("Aug"); ?>
                                <?php endif; ?>
                                <?php if($single->created_at->format('m') == 9): ?>
                                    <?php echo app('translator')->get("Sep"); ?>
                                <?php endif; ?>
                                <?php if($single->created_at->format('m') == 10): ?>
                                    <?php echo app('translator')->get("Oct"); ?>
                                <?php endif; ?>
                                <?php if($single->created_at->format('m') == 11): ?>
                                    <?php echo app('translator')->get("Nov"); ?>
                                <?php endif; ?>
                                <?php if($single->created_at->format('m') == 12): ?>
                                    <?php echo app('translator')->get("Dec"); ?>
                                <?php endif; ?>,
                                <?php echo e($single->created_at->format('Y')); ?></p>
                                <?php if($single->author): ?>
                                    <p><i class="fa fa-user" aria-hidden="true"></i><?php echo e($single->author); ?></p>
                                <?php else: ?> 
                                    <p><i class="fa fa-user" aria-hidden="true"></i><?php echo app('translator')->get("By Admin"); ?></p>
                                <?php endif; ?>
                                
                            </div>
                            <div class="tapo">
                                <p>
                                    <?php
                                    if(strlen($single->body)> 159){
                                        echo substr($single->body, 0, 150)."...";
                                    }else {
                                        echo $single->body;
                                    }  
                                    ?>      
                                </p>
                            </div>
                            <a href="<?php echo e(route('single-news', [app()->getLocale(), $single->id])); ?>" class="ot-btn btn-sub-color"><?php echo app('translator')->get("Read More"); ?></a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php echo e($news->links()); ?>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/UzBRU/resources/views/news/association-news.blade.php ENDPATH**/ ?>