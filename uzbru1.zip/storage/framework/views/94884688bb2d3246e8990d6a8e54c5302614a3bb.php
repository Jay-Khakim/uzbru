<!-- This file is used to store topbar (right) items -->



<?php /**PATH /opt/lampp/htdocs/UzBRU/vendor/backpack/crud/src/resources/views/base/inc/topbar_right_content.blade.php ENDPATH**/ ?>