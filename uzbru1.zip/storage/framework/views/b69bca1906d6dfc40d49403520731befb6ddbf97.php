
<?php
    $array = data_get($entry, $column['name']);
    $suffix = isset($column['suffix']) ? $column['suffix'] : 'items';

    // the value should be an array wether or not attribute casting is used
    if (! is_array($array)) {
        $array = json_decode($array, true);
    }

    if($array && count($array)) {
        $column['text'] = count($array).' '.$suffix;        
    } else {
        $column['text'] = '-';
    }
    
    $column['escaped'] = $column['escaped'] ?? false;
?>

<span>
	<?php echo $__env->renderWhen(!empty($column['wrapper']), 'crud::columns.inc.wrapper_start', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
        <?php if($column['escaped']): ?>
            <?php echo e($column['text']); ?>

        <?php else: ?>
            <?php echo $column['text']; ?>

        <?php endif; ?>
    <?php echo $__env->renderWhen(!empty($column['wrapper']), 'crud::columns.inc.wrapper_end', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
</span>
<?php /**PATH /opt/lampp/htdocs/UzBRU/vendor/backpack/crud/src/resources/views/crud/columns/array_count.blade.php ENDPATH**/ ?>